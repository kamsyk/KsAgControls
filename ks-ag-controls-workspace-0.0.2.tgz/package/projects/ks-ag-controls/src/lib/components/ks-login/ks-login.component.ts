import { Component, inject } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'lib-ks-login',
  imports: [],
  templateUrl: './ks-login.component.html',
  styleUrl: './ks-login.component.css'
})
export class KsLoginComponent {
  private fb = inject(FormBuilder);

  loading = false;
  error = '';

  form = this.fb.group({
    email: ['', [Validators.required, Validators.email]],
    password: ['', [Validators.required]],
  });

  submit() {
    if (this.form.invalid) return;
    this.loading = true;
    this.error = '';
    const { email, password } = this.form.value as { email: string; password: string };
    /*this.auth.login(email, password).subscribe(ok => {
      this.loading = false;
      if (ok) this.dialogRef.close(true);
      else this.error = 'Invalid credentials';
    });*/
  }
}
