export class BaseControl {
}
